const { ethers } = require('ethers');
const fs = require('fs');  // 引入文件系统模块

console.log("程序开始执行");

// 配置项：RPC URL 和合约信息
const RPC_URL = "-----";
const provider = new ethers.providers.JsonRpcProvider(RPC_URL);

const ABI = [{"inputs":[{"internalType":"address","name":"initialOwner","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"allowance","type":"uint256"},{"internalType":"uint256","name":"needed","type":"uint256"}],"name":"ERC20InsufficientAllowance","type":"error"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"uint256","name":"balance","type":"uint256"},{"internalType":"uint256","name":"needed","type":"uint256"}],"name":"ERC20InsufficientBalance","type":"error"},{"inputs":[{"internalType":"address","name":"approver","type":"address"}],"name":"ERC20InvalidApprover","type":"error"},{"inputs":[{"internalType":"address","name":"receiver","type":"address"}],"name":"ERC20InvalidReceiver","type":"error"},{"inputs":[{"internalType":"address","name":"sender","type":"address"}],"name":"ERC20InvalidSender","type":"error"},{"inputs":[{"internalType":"address","name":"spender","type":"address"}],"name":"ERC20InvalidSpender","type":"error"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"OwnableInvalidOwner","type":"error"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"OwnableUnauthorizedAccount","type":"error"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"INITIAL_MINT_LIMIT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_MINT_INTERVAL","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MIN_MINT_INTERVAL","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"ROUND_DURATION","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"lastMint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"mint","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"mintingEnded","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"multiplier","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"nextMintInterval","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"roundStart","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_multiplier","type":"uint256"}],"name":"setRound","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"updateRound","outputs":[],"stateMutability":"nonpayable","type":"function"}];
const CONTRACT_ADDRESS = "0x2f16386bb37709016023232523ff6d9daf444be3";
const BMI_CONTRACT_ADDRESS = "0x86a7cff103df3b0c42a43e52dd25c433cd052319";
const ERC20_ABI = [
    "function balanceOf(address owner) view returns (uint256)",
    "function transfer(address to, uint256 value) returns (bool)"
];

// 延迟函数
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// 批量生成指定数量的钱包并保存到文件
function generateWallets(batchSize) {
    console.log("开始生成钱包...");
    const wallets = [];
    for (let i = 0; i < batchSize; i++) {
        const wallet = ethers.Wallet.createRandom().connect(provider); // 将 provider 连接到每个 wallet
        wallets.push(wallet);

        // 将钱包地址和私钥写入文件
        fs.appendFileSync('wallets.txt', `钱包 ${i + 1}: 地址 - ${wallet.address}, 私钥 - ${wallet.privateKey}\n`);
        console.log(`生成的钱包 ${i + 1}: 地址 - ${wallet.address}, 私钥 - ${wallet.privateKey}`);
    }
    return wallets;
}
// 向多个钱包分发 Gas 费用
async function distributeGas(wallets, fundingWallet, amount) {
    console.log("开始分发 Gas...");
    for (const wallet of wallets) {
        try {
            const tx = await fundingWallet.sendTransaction({
                to: wallet.address,
                value: ethers.utils.parseEther(amount) // 每个钱包的 Gas 费
            });
            await tx.wait();
            console.log(`成功向钱包 ${wallet.address} 分发 Gas，交易哈希: ${tx.hash}`);
   // 等待 15 秒后继续进行铸造操作
    		console.log("等待 15 秒以确保 Gas 分发完成...");
    		await sleep(15000);
            
            // 记录交易哈希到文件
            fs.appendFileSync('transactions.txt', `Gas 分发 - 钱包地址: ${wallet.address}, 交易哈希: ${tx.hash}\n`);
        } catch (error) {
            console.error(`分发 Gas 到钱包 ${wallet.address} 失败`, error);
            fs.appendFileSync('errors.txt', `Gas 分发失败 - 钱包地址: ${wallet.address}, 错误: ${error.message}\n`);
        }
    }
}

// 批量铸造代币到多个钱包地址
async function batchMint(wallets, contract) {
    console.log("开始批量铸造代币...");
    for (const wallet of wallets) {
        try {
            const tx = await contract.connect(wallet).mint();
            await tx.wait();
            console.log(`铸造成功，钱包地址: ${wallet.address}, 交易哈希: ${tx.hash}`);
    // 等待 15 秒后继续进行铸造操作
    console.log("等待 15 秒以确保 Gas 分发完成...");
    await sleep(15000);
            
            // 记录交易哈希到文件
            fs.appendFileSync('mints.txt', `铸造成功 - 钱包地址: ${wallet.address}, 交易哈希: ${tx.hash}\n`);
        } catch (error) {
            console.error(`铸造失败，钱包地址: ${wallet.address}`, error);
            fs.appendFileSync('errors.txt', `铸造失败 - 钱包地址: ${wallet.address}, 错误: ${error.message}\n`);
    // 等待 15 秒后继续进行铸造操作
    console.log("等待 15 秒以确保 Gas 分发完成...");
    await sleep(15000);
        }
    }
}

// 收集代币到一个指定地址
async function collectToken(wallets, targetAddress, contract) {
    console.log("开始收集代币...");
    for (const wallet of wallets) {
        try {
            const balance = await contract.connect(wallet).balanceOf(wallet.address);
            if (balance.gt(0)) {
                const tx = await contract.connect(wallet).transfer(targetAddress, balance);
                await tx.wait();
                console.log(`成功从 ${wallet.address} 收集代币，交易哈希: ${tx.hash}`);
                
                // 记录交易哈希到文件
                fs.appendFileSync('collects.txt', `收集成功 - 钱包地址: ${wallet.address}, 交易哈希: ${tx.hash}\n`);
            }
        } catch (error) {
            console.error(`收集代币失败，钱包地址: ${wallet.address}`, error);
            fs.appendFileSync('errors.txt', `收集失败 - 钱包地址: ${wallet.address}, 错误: ${error.message}\n`);
        }
    }
}

// 主函数
async function main() {
    console.log("主函数启动...");

    // 生成钱包
    const wallets = generateWallets(10); // 生成10个钱包，可以修改数量

    // 设置资金钱包
    const fundingWallet = new ethers.Wallet('你的私钥', provider); // 请替换为你的资金钱包私钥
    const gasAmount = "0.00001"; // 每个钱包分发的 Gas 量

    // 向生成的钱包分发 Gas 费用
    await distributeGas(wallets, fundingWallet, gasAmount);

    // 铸造合约实例
    const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);

    // 批量铸造代币
    await batchMint(wallets, contract);

    // 收集代币到目标地址
    const targetAddress = "收集代币的目标地址"; // 请替换为你的目标地址
    await collectToken(wallets, targetAddress, contract);

    console.log("主函数执行完毕");
}

// 启动主程序
main().catch(error => console.error("发生错误:", error));
